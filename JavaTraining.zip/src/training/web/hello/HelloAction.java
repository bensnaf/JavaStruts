package training.web.hello;

public class HelloAction {
	private String friendName;
	private String message;
	
	public String getFriendName() {
		return friendName;
	}
	
	public void setFriendName(String friendName) {
		this.friendName = friendName;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String init() {
		
		//result
		return "initPage";
	}
	
	public String SayHi() {
		System.out.println("Action instance = " + this);
		message = "Hello" + friendName;
		
		return "resultPage";
	}
}
